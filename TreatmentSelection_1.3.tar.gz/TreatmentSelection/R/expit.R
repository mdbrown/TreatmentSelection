expit <-
function(u) exp(u)/(1+exp(u))
