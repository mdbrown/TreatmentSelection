logit <-
function(u){

sapply( u , logit.one)

}
