is.trtsel <-
function(x){
   inherits(x, "trtsel")
}
