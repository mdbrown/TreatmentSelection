cover <-
function(min, max, value)  !(max < value | min > value)
